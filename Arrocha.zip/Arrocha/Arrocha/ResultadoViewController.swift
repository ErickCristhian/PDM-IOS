//
//  ResultadoViewController.swift
//  Arrocha
//
//  Created by Erick Cristhian Moura da Silva on 17/12/20.
//  Copyright © 2020 Erick Cristhian Moura da Silva. All rights reserved.
//

import UIKit

class ResultadoViewController: UIViewController {
    var resultado: String?
    @IBOutlet weak var lbResultado: UILabel!
    
    override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
    }
}
